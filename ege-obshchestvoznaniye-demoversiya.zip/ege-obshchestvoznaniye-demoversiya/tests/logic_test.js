const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const ctx={window:{EKSAMIO_SOC:{tasks:[],sourceText:'',version:'2026.1',storageKey:'x'}}};vm.createContext(ctx);
for(const n of [2,3,4,5]){const s=fs.readFileSync(`${root}/ege-obshchestvoznaniye-demoversiya-T123-0${n}.txt`,'utf8');const m=[...s.matchAll(/<script>([\s\S]*?)<\/script>/g)];for(const x of m)vm.runInContext(x[1],ctx)}
const tasks=ctx.window.EKSAMIO_SOC.tasks.sort((a,b)=>a.n-b.n);
function rawAnswer(v){return String(v==null?'':v)}
function counts(s){const m={};for(const ch of rawAnswer(s))m[ch]=(m[ch]||0)+1;return m}
function diffCounts(user,key){const u=counts(user),k=counts(key);let extra=0,missing=0;for(const c of new Set([...Object.keys(u),...Object.keys(k)])){extra+=Math.max(0,(u[c]||0)-(k[c]||0));missing+=Math.max(0,(k[c]||0)-(u[c]||0))}return {extra,missing}}
function scoreShort(t,v){const a=rawAnswer(v),k=t.answer;if(!/^\d+$/.test(a))return 0;if(t.scheme==='pos1')return a===k?1:0;if(t.scheme==='set1'){const d=diffCounts(a,k);return d.extra===0&&d.missing===0?1:0}if(t.scheme==='pos2'){if(a.length!==k.length)return 0;let bad=0;for(let i=0;i<k.length;i++)if(a[i]!==k[i])bad++;return bad===0?2:bad===1?1:0}if(t.scheme==='set2'){const d=diffCounts(a,k);if(d.extra===0&&d.missing===0)return 2;if((d.extra===1&&d.missing===0)||(d.extra===0&&d.missing===1)||(d.extra===1&&d.missing===1))return 1;return 0}return 0}
const checks=[];function ck(name,cond,detail=''){checks.push({name,pass:!!cond,detail})}
ck('task_count',tasks.length===25,tasks.length);ck('part1_count',tasks.filter(t=>t.part===1).length===16);ck('part2_count',tasks.filter(t=>t.part===2).length===9);
const total=tasks.filter(t=>t.part===1).reduce((s,t)=>s+scoreShort(t,t.answer),0);ck('correct_keys_total',total===28,total);
ck('task6_one_position_error',scoreShort(tasks.find(t=>t.n===6),'24432')===1);
ck('task7_missing_one',scoreShort(tasks.find(t=>t.n===7),'235')===1);
ck('task7_replacement_one',scoreShort(tasks.find(t=>t.n===7),'2354')===1);
ck('task7_two_errors',scoreShort(tasks.find(t=>t.n===7),'12')===0);
ck('task1_order_independent',scoreShort(tasks.find(t=>t.n===1),'64')===1);
ck('task3_order_sensitive',scoreShort(tasks.find(t=>t.n===3),'12332')===0);
ck('strict_extra_symbols',scoreShort(tasks.find(t=>t.n===2),'x1,3!')===0);
const rubmax=tasks.filter(t=>t.part===2).flatMap(t=>t.rubrics).reduce((s,r)=>s+r.max,0);ck('rubric_max_30',rubmax===30,rubmax);
ck('task21_graph_present',tasks.find(t=>t.n===21).body.includes('D₁'));
ck('task9_chart_present',tasks.find(t=>t.n===9).body.includes('50%'));
ck('task18_full_condition',tasks.find(t=>t.n===18).body.includes('одном или нескольких распространённых предложениях'));
ck('task25_full_condition',tasks.find(t=>t.n===25).body.includes('причинно-следственные')&&tasks.find(t=>t.n===25).body.includes('для решения экологических проблем'));
ck('task25_criterion_precise',tasks.find(t=>t.n===25).rubrics.find(r=>r.id==='25.3').levels['1'].includes('одного или более'));
const runtime=fs.readFileSync(`${root}/ege-obshchestvoznaniye-demoversiya-T123-06.txt`,'utf8');
ck('runtime_strict_form',runtime.includes("if(!/^\\d+$/.test(a))return 0"));
ck('runtime_task24_guard',runtime.includes("x.t.n===24&&x.r.id==='24.2'"));
ck('runtime_storage_guard',runtime.includes('function save(){try{localStorage.setItem'));
console.log(JSON.stringify(checks,null,2));if(checks.some(x=>!x.pass))process.exit(1);
