ПОЛНЫЙ ПАКЕТ ДЛЯ TILDA
Интерактивная демоверсия ЕГЭ по обществознанию 2026
Версия интерактива: 2026.2

Состав:
- SEO и HEAD;
- шесть T123-блоков;
- локальный PREVIEW;
- инструкция установки;
- локальный комплект исходников ФИПИ;
- реестр источников;
- содержательный аудит;
- технический отчёт и тесты;
- SHA-256 manifest.

Статус локального пакета:
CONTENT_STATUS: PASS
JS_SYNTAX_STATUS: PASS
SCORING_UNIT_TESTS: PASS 20/20
LOCAL_BROWSER_STATUS: PASS 25/25
PUBLICATION_STATUS: REQUIRES_TILDA_REPUBLICATION_AND_PRODUCTION_SMOKE

После замены шести T123-блоков нужно перепубликовать страницу Tilda и
проверить production URL, запуск, сохранение, результат 28 + 30 = 58 и
мобильные ширины 320, 360 и 390 px.
