EGE PHYSICS 2024 — TILDA HQ SOURCE v1.1

1. Вставьте содержимое ege-fizika-demoversiya-2024-HEAD.txt в HEAD страницы.
2. Создайте 48 блоков T123 и вставьте ege-fizika-demoversiya-2024-T123-01.txt ... ege-fizika-demoversiya-2024-T123-48.txt строго по порядку.
3. Не меняйте порядок T123: каждый файл самодостаточен и меньше 42500 байт; последний блок запускает интерфейс и scorer.

CANONICAL=https://eksamio.ru/ege/fizika/demoversiya/2024/
SOURCE=canonical FIPI Physics 2024 PDF
SCORER=28+17=45
TEXT_FIDELITY=source-rendered task images; unresolved=0
REFERENCE_PARITY=navigation+calculator+symbol_keyboard+state_restore+result_order
