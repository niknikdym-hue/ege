#!/usr/bin/env python3
import base64, csv, hashlib, io, json, re, shutil, zipfile
from pathlib import Path
import fitz
from PIL import Image, ImageChops

PREFIX='ege-matematika-profil-demoversiya-2026'
HERE=Path(__file__).resolve()
if HERE.parent.name=='scripts' and HERE.parent.parent.name==PREFIX:
    ROOT=HERE.parent.parent
    REPO=ROOT.parent
else:
    REPO=HERE.parents[1]
    ROOT=REPO/PREFIX
SRC=REPO/'matematika-source-2026'/'original'/'МА-11 ЕГЭ 2026 ДЕМО_профильный.pdf'
PACKAGE_VERSION='1.0'
CONTENT_VERSION='2026.1'
STORAGE_KEY='eksamio_ege_math_profile_demo_2026_v1_0'
PERMANENT_URL='https://eksamio.ru/ege/matematika-profil/demoversiya/'
MAX_T123=45000
PART_CHARS=36000

COUNTS={1:4,2:3,3:4,4:3,5:4,6:4,7:3,8:3,9:3,10:3,11:3,12:4,13:2,14:2,15:2,16:2,17:2,18:2,19:2}
ANS={
1:['61','18','40','5'],2:['12','13','4'],3:['1,125','36','104','9'],4:['0,1','0,38','0,3'],5:['0,657','0,15','0,79','0,78'],6:['7','7','93','3'],7:['0,75','5','125'],8:['5','6','1,6'],9:['45','5','4900'],10:['19','15','8'],11:['0,1','5','32'],12:['5','-6','16','-18']}
MAX_EXT={13:2,14:3,15:2,16:2,17:3,18:4,19:4}

# Exact official printed-page crops; coordinates are on 2x rendered printed half-pages (842x1191 px).
COND={
'1-1':(4,315,515),'1-2':(4,595,765),'1-3':(4,845,1010),'1-4':(5,140,275),
'2-1':(5,330,670),'2-2':(5,742,805),'2-3':(5,878,940),
'3-1':(6,110,250),'3-2':(6,320,520),'3-3':(6,590,765),'3-4':(6,845,995),
'4-1':(7,110,248),'4-2':(7,320,440),'4-3':(7,515,635),
'5-1':(7,690,828),'5-2':(7,900,1000),'5-3':(8,125,270),'5-4':(8,340,485),
'6-1':(8,545,645),'6-2':(8,715,777),'6-3':(8,848,912),'6-4':(8,980,1065),
'7-1':(9,115,200),'7-2':(9,270,360),'7-3':(9,430,500),
'8-1':(9,555,960),'8-2':(10,140,460),'8-3':(10,530,895),
'9-1':(11,110,335),'9-2':(11,410,676),'9-3':(11,750,918),
'10-1':(12,110,245),'10-2':(12,315,435),'10-3':(12,510,603),
'11-1':(12,665,1065),'11-2':(13,125,505),'11-3':(13,575,948),
'12-1':(14,120,190),'12-2':(14,260,327),'12-3':(14,400,485),'12-4':(14,560,622),
'13-1':(15,235,365),'13-2':(15,410,535),'14-1':(15,575,740),'14-2':(15,790,960),
'15-1':(16,110,190),'15-2':(16,230,320),'16-1':(16,360,690),'16-2':(16,745,1000),
'17-1':(17,110,225),'17-2':(17,275,455),'18-1':(17,495,625),'18-2':(17,665,780),
'19-1':(18,110,360),'19-2':(18,415,650)}

# Official solution + criteria segments. Multiple segments are stitched vertically.
SOL={
'13-1':[(20,95,1100)],'13-2':[(21,95,1100)],'14-1':[(22,95,1100)],'14-2':[(23,95,1100),(24,95,950)],
'15-1':[(25,95,1100)],'15-2':[(26,95,1100)],'16-1':[(27,95,1100)],'16-2':[(28,95,1100)],
'17-1':[(29,95,1100)],'17-2':[(30,95,1100),(31,95,475)],
'18-1':[(31,485,1100),(32,95,930)],'18-2':[(33,95,1100),(34,95,930)],
'19-1':[(35,95,1100),(36,95,380)],'19-2':[(36,385,1100),(37,95,900)]}

def clean_root():
    if ROOT.exists(): shutil.rmtree(ROOT)
    for d in ['assets','source-evidence','tests/evidence','templates','scripts']:(ROOT/d).mkdir(parents=True,exist_ok=True)

def render_printed(doc,n):
    idx=(n-1)//2; left=(n%2==1); page=doc[idx]; r=page.rect; mid=r.x0+r.width/2
    clip=fitz.Rect(r.x0 if left else mid,r.y0,mid if left else r.x1,r.y1)
    pix=page.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False)
    return Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB')

def trim(im,margin=14):
    bg=Image.new('RGB',im.size,'white'); diff=ImageChops.difference(im,bg).convert('L'); bbox=diff.point(lambda x:0 if x<16 else 255).getbbox()
    if not bbox:return im
    x0,y0,x1,y1=bbox; return im.crop((max(0,x0-margin),max(0,y0-margin),min(im.width,x1+margin),min(im.height,y1+margin)))

def webp(im,path,quality=80):
    im.save(path,'WEBP',quality=quality,method=6)

def make_assets():
    doc=fitz.open(SRC); pages={n:render_printed(doc,n) for n in range(3,38)}; evidence=[]
    for key,(p,y0,y1) in COND.items():
        im=trim(pages[p].crop((90,y0,795,y1)),12); name=f'condition-{key}.webp'; webp(im,ROOT/'assets'/name,82)
        evidence.append({'key':key,'kind':'condition','printed_page':p,'crop':[90,y0,795,y1],'asset':name,'source_identity':'DIRECT_CROP_FROM_OFFICIAL_FIPI_PDF'})
    for key,segs in SOL.items():
        ims=[trim(pages[p].crop((85,y0,800,y1)),10) for p,y0,y1 in segs]; w=max(i.width for i in ims); h=sum(i.height for i in ims)+18*(len(ims)-1)
        out=Image.new('RGB',(w,h),'white'); y=0
        for i,im in enumerate(ims):out.paste(im,((w-im.width)//2,y)); y+=im.height+(18 if i<len(ims)-1 else 0)
        name=f'solution-{key}.webp'; webp(out,ROOT/'assets'/name,78)
        evidence.append({'key':key,'kind':'official_solution_and_criteria','segments':segs,'asset':name,'source_identity':'DIRECT_CROP_FROM_OFFICIAL_FIPI_PDF'})
    ref=trim(pages[3].crop((255,945,600,1095)),10); webp(ref,ROOT/'assets'/'reference-materials.webp',84)
    evidence.append({'kind':'reference_materials','printed_page':3,'crop':[255,945,600,1095],'asset':'reference-materials.webp','source_identity':'DIRECT_CROP_FROM_OFFICIAL_FIPI_PDF'})
    (ROOT/'source-evidence'/'VISUAL-SOURCE-EVIDENCE.json').write_text(json.dumps({'status':'PASS','source_pdf':'МА-11 ЕГЭ 2026 ДЕМО_профильный.pdf','direct_crop_assets':len(evidence),'items':evidence},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def contract_for(t,v):
    if t in (4,5): return {'mode':'probability','hint':'Введите вероятность числом от 0 до 1 без единиц измерения.'}
    if t==8 and v in (1,2): return {'mode':'integer_nonnegative','hint':'Введите количество точек целым неотрицательным числом.'}
    return {'mode':'number','hint':'Введите число без единиц измерения и пробелов.'}

def build_data():
    contracts={}; tasks=[]
    for t in range(1,20):
        vs=[]
        for v in range(1,COUNTS[t]+1):
            key=f'{t}-{v}'; item={'variant':v,'condition_asset':f'condition-{key}.webp','source_page':COND[key][0]}
            if t<=12:
                item['answer']=ANS[t][v-1]; item['control']='numeric_input'; item['input_contract']=contract_for(t,v); contracts[key]=item['input_contract']
            else:
                item['control']='extended_textarea'; item['max_score']=MAX_EXT[t]; item['solution_asset']=f'solution-{key}.webp'
            vs.append(item)
        tasks.append({'number':t,'variants':vs})
    data={'exam':'ЕГЭ','subject':'математика','level':'профильный','sourceYear':2026,'packageVersion':PACKAGE_VERSION,'contentVersion':CONTENT_VERSION,'minutes':235,'maxPrimaryScore':32,'autoMax':12,'selfMax':20,'storageKey':STORAGE_KEY,'permanentUrl':PERMANENT_URL,'officialExampleCount':55,'tasks':tasks}
    (ROOT/f'{PREFIX}-EXAM-DATA.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (ROOT/f'{PREFIX}-INPUT-CONTRACT.json').write_text(json.dumps({'status':'BUILT','contracts':contracts},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (ROOT/f'{PREFIX}-OFFICIAL-ANSWERS.json').write_text(json.dumps({'source':'ФИПИ 2026, профильный уровень, таблица ответов демоверсии','answers':{str(k):v for k,v in ANS.items()}},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return data

def shell(data):
    cfg={k:data[k] for k in ['packageVersion','contentVersion','minutes','maxPrimaryScore','autoMax','selfMax','storageKey','permanentUrl','officialExampleCount']}
    tasks=json.dumps(data['tasks'],ensure_ascii=False,separators=(',',':'))
    return '''<style>
#mp-app{font-family:Arial,sans-serif;color:#172033;background:#f6f8fc;padding:24px 14px;line-height:1.45}#mp-app *{box-sizing:border-box}.mp-wrap{max-width:1160px;margin:0 auto}.mp-card{background:#fff;border:1px solid #e2e7f0;border-radius:18px;box-shadow:0 10px 32px rgba(28,45,84,.07)}.mp-intro{padding:34px}.mp-eyebrow{font-size:13px;font-weight:700;color:#4263eb;text-transform:uppercase;letter-spacing:.04em}.mp-h1{font-size:34px;line-height:1.12;margin:8px 0 14px}.mp-lead{font-size:17px;color:#536074;max-width:820px}.mp-chips{display:flex;flex-wrap:wrap;gap:8px;margin:20px 0}.mp-chip{background:#eef3ff;border-radius:999px;padding:7px 11px;font-size:13px}.mp-actions{display:flex;gap:10px;flex-wrap:wrap}.mp-btn{border:0;border-radius:12px;padding:11px 16px;font-weight:700;cursor:pointer;font-size:14px}.mp-primary{background:#2457e6;color:#fff}.mp-secondary{background:#edf1f7;color:#22304a}.mp-danger{background:#fff0f0;color:#b42318}.mp-hidden{display:none!important}.mp-exam{display:none}.mp-exam.is-active{display:block}.mp-top{position:sticky;top:0;z-index:20;background:rgba(246,248,252,.96);backdrop-filter:blur(8px);padding:8px 0 12px}.mp-bar{display:flex;align-items:center;gap:10px;padding:12px 15px}.mp-timer{font-size:20px;font-weight:800;margin-right:auto}.mp-progress{height:5px;background:#e8edf5;border-radius:10px;overflow:hidden}.mp-progress>span{display:block;height:100%;background:#2457e6}.mp-layout{display:grid;grid-template-columns:220px 1fr;gap:16px}.mp-side{padding:16px;align-self:start;position:sticky;top:92px}.mp-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.mp-num{height:39px;border:1px solid #d8dfeb;background:#fff;border-radius:9px;font-weight:700;cursor:pointer}.mp-num.is-current{outline:2px solid #2457e6}.mp-num.is-filled{background:#e9f8ef;border-color:#9bd5ae}.mp-num.is-marked{box-shadow:inset 0 -4px 0 #f59e0b}.mp-legend{font-size:12px;color:#67748a;margin-top:14px}.mp-task{padding:25px;min-width:0}.mp-task-head{display:flex;align-items:flex-start;gap:10px;margin-bottom:14px}.mp-task-head h2{margin:0;font-size:25px}.mp-meta{font-size:13px;color:#657289}.mp-mark{margin-left:auto}.mp-source-tag{font-size:12px;color:#657289;margin:3px 0 13px}.mp-source{background:#fff;border:1px solid #e3e7ef;border-radius:12px;padding:8px;text-align:center;overflow:auto}.mp-source-img{display:block;max-width:100%;height:auto;margin:auto}.mp-answerbox{margin-top:16px;padding:16px;border:1px solid #dce3ef;background:#fbfcff;border-radius:14px}.mp-answer-title{display:block;font-weight:800;margin-bottom:5px}.mp-hint{font-size:13px;color:#637087;margin-bottom:9px}.mp-input{width:100%;max-width:430px;border:1px solid #bcc7d8;border-radius:10px;padding:12px 13px;font-size:18px}.mp-input.is-invalid{border-color:#d92d20;background:#fff8f7}.mp-error{min-height:20px;color:#b42318;font-size:13px;margin-top:5px}.mp-textarea{width:100%;min-height:240px;resize:vertical;border:1px solid #bcc7d8;border-radius:10px;padding:13px;font:16px/1.5 Arial,sans-serif}.mp-nav{display:flex;justify-content:space-between;gap:10px;margin-top:18px}.mp-results{display:none}.mp-results.is-active{display:block}.mp-results-card{padding:28px}.mp-score-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:18px 0}.mp-scorebox{background:#f5f8ff;border:1px solid #dbe5ff;border-radius:14px;padding:15px}.mp-scorebox strong{display:block;font-size:27px}.mp-result-list{display:grid;gap:9px}.mp-result-item{display:flex;justify-content:space-between;gap:12px;padding:10px 12px;border-radius:10px;background:#f7f9fc}.mp-ok{color:#087a3e}.mp-bad{color:#b42318}.mp-ext{margin-top:18px;border-top:1px solid #e3e7ef;padding-top:18px}.mp-ext-card{border:1px solid #dfe5ee;border-radius:14px;padding:16px;margin:12px 0}.mp-ext-card h3{margin:0 0 8px}.mp-solution{margin:12px 0;background:#fff;border:1px solid #e2e7ef;border-radius:10px;padding:8px;max-height:900px;overflow:auto}.mp-self-buttons{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}.mp-score-btn{border:1px solid #cfd7e5;background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer}.mp-score-btn.is-on{background:#2457e6;color:#fff;border-color:#2457e6}.mp-modal{position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:50;display:flex;align-items:center;justify-content:center;padding:20px}.mp-modal-card{background:#fff;border-radius:16px;max-width:760px;width:100%;max-height:90vh;overflow:auto;padding:18px}.mp-modal-head{display:flex;align-items:center;justify-content:space-between}.mp-modal-head h3{margin:0}.mp-close{border:0;background:#eef1f6;border-radius:9px;padding:8px 11px;cursor:pointer}@media(max-width:800px){#mp-app{padding:12px 8px}.mp-h1{font-size:27px}.mp-layout{grid-template-columns:1fr}.mp-side{position:static}.mp-grid{grid-template-columns:repeat(7,1fr)}.mp-task{padding:17px}.mp-score-row{grid-template-columns:1fr}.mp-top{position:static}}@media(max-width:420px){.mp-grid{grid-template-columns:repeat(5,1fr)}.mp-bar{flex-wrap:wrap}.mp-timer{width:100%}.mp-intro{padding:22px}.mp-h1{font-size:24px}.mp-task-head{flex-wrap:wrap}.mp-mark{margin-left:0}.mp-btn{padding:10px 12px}}
</style><div id="mp-app"><div class="mp-wrap"><section id="mp-intro" class="mp-card mp-intro"><div class="mp-eyebrow">Эксамио · ЕГЭ</div><h1 class="mp-h1">Интерактивная демоверсия ЕГЭ по профильной математике 2026</h1><p class="mp-lead">Официальные примеры ФИПИ: 12 заданий с кратким ответом и 7 заданий с развёрнутым решением. Краткая часть проверяется автоматически; развёрнутая оценивается вами отдельно по официальным критериям после завершения попытки.</p><div class="mp-chips"><span class="mp-chip">19 заданий</span><span class="mp-chip">235 минут</span><span class="mp-chip">32 первичных балла</span><span class="mp-chip">55 официальных примеров</span></div><div class="mp-actions"><button id="mp-start" class="mp-btn mp-primary">Начать попытку</button><button id="mp-continue" class="mp-btn mp-secondary mp-hidden">Продолжить</button><button id="mp-ref-intro" class="mp-btn mp-secondary">Справочные материалы</button><button id="mp-reset-intro" class="mp-btn mp-danger mp-hidden">Удалить попытку</button></div></section><section id="mp-exam" class="mp-exam"><div class="mp-top"><div class="mp-card mp-bar"><div class="mp-timer" id="mp-timer">03:55:00</div><button id="mp-ref" class="mp-btn mp-secondary">Справка</button><button id="mp-finish" class="mp-btn mp-primary">Завершить</button></div><div class="mp-progress"><span id="mp-progress"></span></div></div><div class="mp-layout"><aside class="mp-card mp-side"><div id="mp-grid" class="mp-grid"></div><div class="mp-legend">Зелёный — заполнено · оранжевая метка — вернуться · синяя рамка — открыто.</div></aside><main id="mp-task" class="mp-card mp-task"></main></div></section><section id="mp-results" class="mp-results"><div class="mp-card mp-results-card"><h2>Результат попытки</h2><div class="mp-score-row"><div class="mp-scorebox">Автоматически, №1–12<strong id="mp-auto-score">—</strong></div><div class="mp-scorebox">Самооценка, №13–19<strong id="mp-self-score">—</strong></div><div class="mp-scorebox">Итого по самооценке<strong id="mp-total-score">—</strong></div></div><div id="mp-short-results" class="mp-result-list"></div><div class="mp-ext"><h2>Развёрнутая часть: официальные решения и критерии</h2><p class="mp-hint">Выберите балл только после сравнения своего решения с официальным решением и критериями ФИПИ. Это самостоятельная оценка, а не автоматическая проверка.</p><div id="mp-ext-results"></div></div><div class="mp-actions"><button id="mp-new" class="mp-btn mp-primary">Новая попытка</button><button id="mp-ref-results" class="mp-btn mp-secondary">Справочные материалы</button></div></div></section></div><div id="mp-modal" class="mp-modal mp-hidden"><div class="mp-modal-card"><div class="mp-modal-head"><h3>Справочные материалы ФИПИ 2026</h3><button id="mp-close" class="mp-close">Закрыть</button></div><div id="mp-ref-body"></div></div></div></div><script>window.EKSAMIO_MATH_PROFILE='''+json.dumps(cfg,ensure_ascii=False,separators=(',',':'))[:-1]+''',"tasks":'''+tasks+''',"assetParts":{}};</script>'''

def runtime():
    return r'''(function(){'use strict';const C=window.EKSAMIO_MATH_PROFILE,$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];C.assets={};for(const[k,v]of Object.entries(C.assetParts))C.assets[k]='data:image/webp;base64,'+v.join('');const tasks=C.tasks,byN=n=>tasks.find(t=>t.number===n);function empty(){return{version:C.contentVersion,started:false,finished:false,current:1,startedAt:null,deadline:null,variants:{},answers:{},marked:{},selfScores:{}}}function load(){try{const s=JSON.parse(localStorage.getItem(C.storageKey)||'null');if(s&&s.version===C.contentVersion)return Object.assign(empty(),s)}catch(e){}return empty()}let state=load(),timer=null;function save(){localStorage.setItem(C.storageKey,JSON.stringify(state))}function rnd(max){if(crypto&&crypto.getRandomValues){const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%max}return Math.floor(Math.random()*max)}function variantFor(n){const t=byN(n),k=Number(state.variants[n]||t.variants[0].variant);return t.variants.find(v=>v.variant===k)||t.variants[0]}function assign(){state.variants={};for(const t of tasks)state.variants[t.number]=t.variants[rnd(t.variants.length)].variant}function ans(n){return state.answers[n]||null}function validate(v,raw){const c=v.input_contract,s=String(raw==null?'':raw);if(!s)return{empty:true,valid:false,reason:null,value:''};if(s.includes('%'))return{valid:false,reason:'percent',value:s};if(/[A-Za-zА-Яа-яЁё°²³]/.test(s))return{valid:false,reason:'unit',value:s};if(s.includes('/'))return{valid:false,reason:'fraction',value:s};if(s.includes('+'))return{valid:false,reason:'plus',value:s};if(/\s/.test(s))return{valid:false,reason:'space',value:s};if(c.mode==='integer_nonnegative'){if(/[.,]/.test(s))return{valid:false,reason:'integer',value:s};if(!/^\d+$/.test(s))return{valid:false,reason:'format',value:s};return{valid:true,reason:null,value:s}}let x=s.replace('−','-');const seps=(x.match(/[.,]/g)||[]).length;if(seps>1)return{valid:false,reason:'separator',value:s};if(/[.,]$/.test(x))return{valid:false,reason:'incomplete_decimal',value:x.replace('.',',')};if(!/^-?\d+(?:[.,]\d+)?$/.test(x))return{valid:false,reason:'format',value:s};x=x.replace('.',',');if(c.mode==='probability'){const z=Number(x.replace(',','.'));if(z<0||z>1)return{valid:false,reason:'probability',value:x}}return{valid:true,reason:null,value:x}}function err(v,r){if(r==='space')return'Пробелы в поле ответа не используются.';if(r==='plus')return'Знак «+» в поле ответа не нужен.';if(r==='percent')return v.input_contract.mode==='probability'?'Знак «%» не вводится. Запишите вероятность числом от 0 до 1.':'Знак «%» в поле ответа не используется.';if(r==='unit')return'Единицы измерения и буквы в поле ответа не вводятся.';if(r==='fraction')return'Обыкновенную дробь через «/» вводить нельзя: запишите целое число или конечную десятичную дробь.';if(r==='integer')return'Для этого задания нужно ввести целое число без запятой и дробной части.';if(r==='probability')return'Вероятность должна быть числом от 0 до 1.';if(r==='separator')return'В числе может быть только один десятичный разделитель.';if(r==='incomplete_decimal')return'После запятой укажите цифры.';return'Введите число в формате, указанном для этого задания.'}function isAnswered(n){const v=variantFor(n),a=ans(n);if(!a)return false;if(n<=12)return !!(a.valid&&String(a.value||'')!=='');return !!String(a.text||'').trim()}function scoreShort(n){if(n>12)return 0;const v=variantFor(n),a=ans(n);if(!a||!a.valid)return 0;const x=Number(String(a.value).replace(',','.')),y=Number(String(v.answer).replace(',','.'));return Number.isFinite(x)&&Math.abs(x-y)<1e-9?1:0}function autoTotal(){let s=0;for(let n=1;n<=12;n++)s+=scoreShort(n);return s}function start(){state=empty();state.started=true;state.startedAt=Date.now();state.deadline=state.startedAt+C.minutes*60000;assign();save();showExam();render()}function resume(){showExam();render()}function showIntro(){clearInterval(timer);$('#mp-intro').classList.remove('mp-hidden');$('#mp-exam').classList.remove('is-active');$('#mp-results').classList.remove('is-active');const has=state.started&&!state.finished;$('#mp-continue').classList.toggle('mp-hidden',!has);$('#mp-reset-intro').classList.toggle('mp-hidden',!has)}function showExam(){$('#mp-intro').classList.add('mp-hidden');$('#mp-results').classList.remove('is-active');$('#mp-exam').classList.add('is-active');startTimer()}function img(name,cls='mp-source-img'){return`<img class="${cls}" src="${C.assets[name]}" alt="Официальный материал ФИПИ к заданию" loading="eager">`}function renderGrid(){$('#mp-grid').innerHTML=tasks.map(t=>`<button class="mp-num ${t.number===state.current?'is-current':''} ${isAnswered(t.number)?'is-filled':''} ${state.marked[t.number]?'is-marked':''}" data-n="${t.number}">${t.number}</button>`).join('');$$('.mp-num').forEach(b=>b.onclick=()=>{state.current=+b.dataset.n;save();render()})}function answerPanel(v){if(state.current<=12){const a=ans(state.current)||{value:'',valid:false},chk=validate(v,a.value||''),bad=!chk.empty&&!chk.valid;return`<div class="mp-answerbox"><label class="mp-answer-title" for="mp-short">Ответ</label><div class="mp-hint">${v.input_contract.hint}</div><input id="mp-short" class="mp-input ${bad?'is-invalid':''}" inputmode="${v.input_contract.mode==='integer_nonnegative'?'numeric':'decimal'}" autocomplete="off" value="${esc(a.value||'')}"><div id="mp-error" class="mp-error" aria-live="polite">${bad?esc(err(v,chk.reason)):''}</div></div>`}const a=ans(state.current)||{text:''};return`<div class="mp-answerbox"><label class="mp-answer-title" for="mp-long">Полное решение</label><div class="mp-hint">Запишите полное обоснованное решение и ответ. Официальное решение и критерии откроются только после завершения попытки.</div><textarea id="mp-long" class="mp-textarea" spellcheck="false">${esc(a.text||'')}</textarea></div>`}function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function render(){const v=variantFor(state.current);$('#mp-progress').style.width=(state.current/19*100)+'%';$('#mp-task').innerHTML=`<div class="mp-task-head"><div><h2>Задание ${state.current}</h2><div class="mp-meta">${state.current<=12?'Часть 1 · краткий ответ · 1 балл':'Часть 2 · развёрнутый ответ · до '+v.max_score+' балл.'}</div></div><button id="mp-mark" class="mp-btn mp-secondary mp-mark">${state.marked[state.current]?'★ Вернуться':'☆ Вернуться позже'}</button></div><div class="mp-source-tag">ФИПИ 2026 · официальный пример ${v.variant}</div><div class="mp-source">${img(v.condition_asset)}</div>${answerPanel(v)}<div class="mp-nav"><button id="mp-prev" class="mp-btn mp-secondary" ${state.current===1?'disabled':''}>← Назад</button><button id="mp-next" class="mp-btn mp-primary">${state.current===19?'Завершить':'Далее →'}</button></div>`;$('#mp-mark').onclick=()=>{state.marked[state.current]=!state.marked[state.current];save();renderGrid();render()};if(state.current<=12)bindShort(v);else bindLong();$('#mp-prev').onclick=()=>{if(state.current>1){state.current--;save();render()}};$('#mp-next').onclick=()=>{if(state.current===19)finish();else{state.current++;save();render()}};renderGrid()}function bindShort(v){const i=$('#mp-short'),e=$('#mp-error');i.oninput=()=>{let raw=i.value,chk=validate(v,raw);if(v.input_contract.mode!=='integer_nonnegative'&&chk.value!==raw&&(chk.valid||chk.reason==='incomplete_decimal')){raw=chk.value;i.value=raw;chk=validate(v,raw)}i.classList.toggle('is-invalid',!chk.empty&&!chk.valid);e.textContent=chk.empty||chk.valid?'':err(v,chk.reason);state.answers[state.current]={value:raw,valid:!!chk.valid};save();renderGrid()}}function bindLong(){const t=$('#mp-long');t.oninput=()=>{state.answers[state.current]={text:t.value};save();renderGrid()}}function finish(){const done=tasks.filter(t=>isAnswered(t.number)).length;if(!confirm(done<19?`Заполнено ${done} из 19. Завершить попытку?`:'Завершить попытку и перейти к результатам?'))return;state.finished=true;state.started=false;save();showResults()}function showResults(){clearInterval(timer);$('#mp-intro').classList.add('mp-hidden');$('#mp-exam').classList.remove('is-active');$('#mp-results').classList.add('is-active');$('#mp-auto-score').textContent=autoTotal()+'/12';$('#mp-short-results').innerHTML=Array.from({length:12},(_,i)=>{const n=i+1,v=variantFor(n),a=ans(n),ok=scoreShort(n)===1;return`<div class="mp-result-item"><span>№${n} · ваш ответ: <strong>${esc(a&&a.value||'—')}</strong> · официальный: <strong>${esc(v.answer)}</strong></span><strong class="${ok?'mp-ok':'mp-bad'}">${ok?'1/1':'0/1'}</strong></div>`}).join('');$('#mp-ext-results').innerHTML=Array.from({length:7},(_,i)=>{const n=13+i,v=variantFor(n),chosen=state.selfScores[n];return`<div class="mp-ext-card" data-ext="${n}"><h3>Задание ${n} · официальный пример ${v.variant}</h3><div class="mp-hint">Ваше решение сохранено. Сравните его с официальным решением и критериями ниже.</div><div class="mp-solution">${img(v.solution_asset)}</div><strong>Самооценка: выберите 0–${v.max_score}</strong><div class="mp-self-buttons">${Array.from({length:v.max_score+1},(_,s)=>`<button class="mp-score-btn ${Number(chosen)===s?'is-on':''}" data-n="${n}" data-s="${s}">${s}</button>`).join('')}</div></div>`}).join('');$$('.mp-score-btn').forEach(b=>b.onclick=()=>{state.selfScores[+b.dataset.n]=+b.dataset.s;save();updateSelf();$$(`.mp-score-btn[data-n="${b.dataset.n}"]`).forEach(x=>x.classList.toggle('is-on',x===b))});updateSelf()}function updateSelf(){const vals=[];for(let n=13;n<=19;n++)if(Object.prototype.hasOwnProperty.call(state.selfScores,n))vals.push(Number(state.selfScores[n]));if(vals.length===7){const s=vals.reduce((a,b)=>a+b,0);$('#mp-self-score').textContent=s+'/20';$('#mp-total-score').textContent=(autoTotal()+s)+'/32'}else{$('#mp-self-score').textContent=vals.length?`${vals.reduce((a,b)=>a+b,0)}/20 · оценено ${vals.length}/7`:'не оценено';$('#mp-total-score').textContent='—'}}function startTimer(){clearInterval(timer);const tick=()=>{const left=Math.max(0,(state.deadline||Date.now())-Date.now()),sec=Math.ceil(left/1000),h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=sec%60;$('#mp-timer').textContent=[h,m,s].map(x=>String(x).padStart(2,'0')).join(':');if(left<=0&&!state.finished){state.finished=true;state.started=false;save();showResults()}};tick();timer=setInterval(tick,1000)}function openRef(){$('#mp-ref-body').innerHTML=`<div class="mp-source">${img('reference-materials.webp')}</div>`;$('#mp-modal').classList.remove('mp-hidden')}function closeRef(){$('#mp-modal').classList.add('mp-hidden')}$('#mp-start').onclick=start;$('#mp-continue').onclick=resume;$('#mp-reset-intro').onclick=()=>{if(confirm('Удалить сохранённую попытку?')){localStorage.removeItem(C.storageKey);state=empty();showIntro()}};$('#mp-ref-intro').onclick=$('#mp-ref').onclick=$('#mp-ref-results').onclick=openRef;$('#mp-close').onclick=closeRef;$('#mp-modal').onclick=e=>{if(e.target.id==='mp-modal')closeRef()};$('#mp-finish').onclick=finish;$('#mp-new').onclick=()=>{if(confirm('Начать новую попытку?'))start()};window.EKSAMIO_MATH_PROFILE_TEST={tasks,variantFor,state:()=>state,forceVariant:(n,v)=>{state.variants[n]=v;state.current=n;save();if(!state.finished)render()},setCurrent:n=>{state.current=n;save();if(!state.finished)render()},scoreShort,isAnswered,autoTotal,finishNoConfirm:()=>{state.finished=true;state.started=false;save();showResults()},validate};if(state.finished)showResults();else showIntro()})();'''

def write_text_files(data):
    (ROOT/f'{PREFIX}-SEO.txt').write_text('TITLE: Интерактивная демоверсия ЕГЭ по профильной математике | Эксамио\nDESCRIPTION: Пройдите интерактивную демоверсию ЕГЭ по профильной математике: краткая часть с автоматической проверкой и развёрнутые задания с самостоятельной оценкой по критериям.\nKEYWORDS: демоверсия ЕГЭ профильная математика, ЕГЭ математика профиль, интерактивная демоверсия\nPAGE_URL: '+PERMANENT_URL+'\n',encoding='utf-8')
    (ROOT/f'{PREFIX}-HEAD.txt').write_text(f'''<link rel="canonical" href="{PERMANENT_URL}">\n<meta property="og:type" content="website">\n<meta property="og:site_name" content="Эксамио">\n<meta property="og:title" content="Интерактивная демоверсия ЕГЭ по профильной математике">\n<meta property="og:description" content="Краткая часть с автоматической проверкой и развёрнутые задания с самостоятельной оценкой по критериям.">\n<meta property="og:url" content="{PERMANENT_URL}">\n''',encoding='utf-8')
    exam={'exam':'ЕГЭ','subject':'математика','level':'профильный','source_year':2026,'package_version':PACKAGE_VERSION,'permanent_url':PERMANENT_URL,'task_count':19,'short_answer_tasks':list(range(1,13)),'extended_answer_tasks':list(range(13,20)),'duration_minutes':235,'max_primary_score':32,'automatic_max':12,'self_evaluation_max':20,'extended_max_scores':{str(k):v for k,v in MAX_EXT.items()},'official_examples_total':55,'official_example_counts':{str(k):v for k,v in COUNTS.items()},'storage_key':STORAGE_KEY,'release_status':'BUILT_PENDING_TESTS'}
    (ROOT/f'{PREFIX}-EXAM-MAP.json').write_text(json.dumps(exam,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    contract={'package_version':PACKAGE_VERSION,'source_year':2026,'permanent_url':PERMANENT_URL,'header_footer_included':False,'canonical_year_free':True,'variant_contract':{'one_official_example_per_position':True,'student_selects_variant':False,'variant_persists_after_reload':True,'official_examples_total':55},'scoring_contract':{'tasks_1_12':'automatic 0–12','tasks_13_19':'self-evaluation only after finish, 0–20, using official FIPI criteria','total':'automatic + explicit self-evaluation, max 32','no_hidden_mix':True},'source_contract':{'conditions':'direct crops from official FIPI 2026 PDF','solutions_and_criteria':'direct crops from official FIPI 2026 PDF'}}
    (ROOT/f'{PREFIX}-PACKAGE-CONTRACT.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (ROOT/f'{PREFIX}-PAGE-STATUS.txt').write_text('PAGE_URL: /ege/matematika-profil/demoversiya/\nPAGE_SLUG: ege-matematika-profil-demoversiya\nEXAM: ЕГЭ\nSUBJECT: математика\nLEVEL: профильный\nSOURCE_YEAR: 2026\nPACKAGE_VERSION: 1.0\nSOURCE_GATE: PASS\nTEXT_TYPOGRAPHY_GATE: PASS — official conditions are direct source crops\nFORMULA_GATE: PASS — formulas rendered directly from official PDF crops\nVISUAL_GATE: PASS — condition/graph/diagram assets are direct official PDF crops\nINTERACTION_GATE: PENDING\nSCORER_GATE: PENDING\nSTATE_RESTORE_GATE: PENDING\nEXTENDED_SELF_EVALUATION_GATE: PENDING\nTILDA_SIZE_GATE: PENDING\nINDEPENDENT_AUDIT_GATE: PENDING\nFINAL_STATUS: BUILT_PENDING_TESTS\nPUBLISHED_SMOKE_STATUS: NOT_RUN_UNTIL_TILDA_PUBLICATION\n',encoding='utf-8')
    rows=[]
    for t in data['tasks']:
        for v in t['variants']:
            rows.append({'year':2026,'level':'profile','task':t['number'],'official_example':v['variant'],'source_page':v['source_page'],'control':v['control'],'official_answer_or_max':v.get('answer',v.get('max_score')),'condition_asset':v['condition_asset'],'solution_asset':v.get('solution_asset',''),'source_gate':'PASS','visual_gate':'PASS','interaction_gate':'PENDING'})
    with (ROOT/'AUDIT-MATRIX-2026-profile.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    (ROOT/'AUDIT-REPORT-2026-profile.md').write_text('# Аудит — ЕГЭ профильная математика 2026\n\nСтатус: BUILT_PENDING_TESTS.\n\n- Источник: официальный комплект ФИПИ 2026.\n- 55 официальных примеров представлены отдельными строками audit matrix.\n- Условия, формулы, графики и рисунки используются как прямые фрагменты официального PDF.\n- №1–12: автоматический результат /12.\n- №13–19: самостоятельная оценка /20 только после завершения, по официальным решениям и критериям.\n',encoding='utf-8')

def build_blocks(data):
    # Tilda-safe packing: shell/runtime stay isolated; sequential asset payloads are combined
    # without exceeding the conservative 42.5 kB gate.
    blocks=[shell(data)]
    asset_scripts=[]
    for p in sorted((ROOT/'assets').glob('*.webp')):
        b64=base64.b64encode(p.read_bytes()).decode('ascii'); parts=[b64[i:i+PART_CHARS] for i in range(0,len(b64),PART_CHARS)]
        for part in parts:
            asset_scripts.append(f'<script>window.EKSAMIO_MATH_PROFILE.assetParts[{json.dumps(p.name)}]=window.EKSAMIO_MATH_PROFILE.assetParts[{json.dumps(p.name)}]||[];window.EKSAMIO_MATH_PROFILE.assetParts[{json.dumps(p.name)}].push({json.dumps(part)});</script>')
    packed=''; safe_limit=42500
    for script in asset_scripts:
        candidate=packed+script
        if packed and len(candidate.encode('utf-8'))>=safe_limit:
            blocks.append(packed); packed=script
        else:
            packed=candidate
    if packed: blocks.append(packed)
    blocks.append('<script>'+runtime()+'</script>')
    for old in ROOT.glob(f'{PREFIX}-T123-*.txt'):old.unlink()
    names=[]
    for i,b in enumerate(blocks,1):
        size=len(b.encode('utf-8'))
        if size>=MAX_T123:raise RuntimeError(f'T123 {i} too large: {size}')
        name=f'{PREFIX}-T123-{i:02d}.txt';(ROOT/name).write_text(b,encoding='utf-8');names.append(name)
    return names

def preview_and_install(names):
    head=(ROOT/f'{PREFIX}-HEAD.txt').read_text(encoding='utf-8');body='\n'.join((ROOT/n).read_text(encoding='utf-8') for n in names)
    (ROOT/f'{PREFIX}-PREVIEW.html').write_text('<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+head+'</head><body>'+body+'</body></html>',encoding='utf-8')
    (ROOT/f'{PREFIX}-INSTALLATION.txt').write_text('УСТАНОВКА В TILDA\nПакет: '+PREFIX+'-v'+PACKAGE_VERSION+'\n\n1. SEO и HEAD — из одноимённых файлов.\n2. Создать '+str(len(names))+' блоков T123 и вставить строго по порядку ниже.\n3. Между ними не вставлять другие блоки.\n4. Шапка и футер подключаются отдельно.\n5. После публикации выполнить production smoke-test.\n\nПОРЯДОК T123:\n'+'\n'.join(names)+'\n',encoding='utf-8')

def manifest_zip():
    manifest=ROOT/f'{PREFIX}-MANIFEST-SHA256.txt'
    if manifest.exists():manifest.unlink()
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name!=manifest.name and '__pycache__' not in p.parts and p.suffix!='.pyc')
    manifest.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n' for p in files),encoding='utf-8')
    out=REPO/f'{PREFIX}-v{PACKAGE_VERSION}.zip'
    if out.exists():out.unlink()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    return out

def main():
    clean_root();make_assets();data=build_data();write_text_files(data);names=build_blocks(data);preview_and_install(names)
    sizes={n:(ROOT/n).stat().st_size for n in names};ev={'status':'BUILT_PENDING_TESTS','package_version':PACKAGE_VERSION,'tasks':19,'official_examples':55,'short_examples':41,'extended_examples':14,'assets':len(list((ROOT/'assets').glob('*.webp'))),'t123_blocks':len(names),'t123_max_bytes':max(sizes.values()),'t123_sizes':sizes}
    (ROOT/f'{PREFIX}-BUILD-EVIDENCE.json').write_text(json.dumps(ev,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=manifest_zip();print(json.dumps({**ev,'package':out.name},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
