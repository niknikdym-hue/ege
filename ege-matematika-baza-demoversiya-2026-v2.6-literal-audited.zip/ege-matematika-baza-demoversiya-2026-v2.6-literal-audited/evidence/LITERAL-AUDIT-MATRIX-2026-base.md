# LITERAL AUDIT MATRIX — ЕГЭ математика, базовый уровень, 2026

> Каждая строка — отдельный официальный пример ФИПИ. PASS без путей к доказательствам не допускается.

| Задание | Вариант | PDF стр. | Текст/пунктуация | Типографика | Формула | Таблица | Рисунок | Действие → контрол | Ответ/scorer | Save/reload | Статус |
|---:|---:|---:|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 4 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 6 / PASS | PASS/PASS | **PASS** |
| 1 | 2 | 4 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 520 / PASS | PASS/PASS | **PASS** |
| 1 | 3 | 4 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 12 / PASS | PASS/PASS | **PASS** |
| 1 | 4 | 4 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 6 / PASS | PASS/PASS | **PASS** |
| 2 | 1 | 5 | PASS/PASS | PASS | N/A | PASS | N/A | matching → selectx4 | 3412 / PASS | PASS/PASS | **PASS** |
| 2 | 2 | 5 | PASS/PASS | PASS | N/A | PASS | N/A | matching → selectx4 | 4123 / PASS | PASS/PASS | **PASS** |
| 3 | 1 | 5 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 24 / PASS | PASS/PASS | **PASS** |
| 3 | 2 | 5 | PASS/PASS | PASS | N/A | PASS | N/A | text → input | 3 / PASS | PASS/PASS | **PASS** |
| 3 | 3 | 6 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 12200 / PASS | PASS/PASS | **PASS** |
| 4 | 1 | 6 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 25 / PASS | PASS/PASS | **PASS** |
| 4 | 2 | 6 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 9 / PASS | PASS/PASS | **PASS** |
| 4 | 3 | 6 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 41 / PASS | PASS/PASS | **PASS** |
| 5 | 1 | 6 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 0.25 / PASS | PASS/PASS | **PASS** |
| 5 | 2 | 6 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 0.4 / PASS | PASS/PASS | **PASS** |
| 5 | 3 | 6 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 0.36 / PASS | PASS/PASS | **PASS** |
| 6 | 1 | 7 | PASS/PASS | PASS | N/A | PASS | N/A | multi → checkbox | 15|51|236|263|326|362|623|632 / PASS | PASS/PASS | **PASS** |
| 6 | 2 | 7 | PASS/PASS | PASS | N/A | PASS | N/A | multi → checkbox | 15|51 / PASS | PASS/PASS | **PASS** |
| 6 | 3 | 7 | PASS/PASS | PASS | N/A | PASS | N/A | text → input | 192000 / PASS | PASS/PASS | **PASS** |
| 7 | 1 | 7 | PASS/PASS | PASS | PASS | PASS | PASS | matching → selectx4 | 2143 / PASS | PASS/PASS | **PASS** |
| 7 | 2 | 8 | PASS/PASS | PASS | N/A | PASS | PASS | matching → selectx4 | 4312 / PASS | PASS/PASS | **PASS** |
| 7 | 3 | 8 | PASS/PASS | PASS | N/A | PASS | PASS | matching → selectx4 | 2143 / PASS | PASS/PASS | **PASS** |
| 8 | 1 | 9 | PASS/PASS | PASS | N/A | N/A | N/A | multi → checkbox | 14 / PASS | PASS/PASS | **PASS** |
| 8 | 2 | 9 | PASS/PASS | PASS | N/A | N/A | N/A | multi → checkbox | 12 / PASS | PASS/PASS | **PASS** |
| 9 | 1 | 9 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 3 / PASS | PASS/PASS | **PASS** |
| 9 | 2 | 9 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 27 / PASS | PASS/PASS | **PASS** |
| 10 | 1 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 1420 / PASS | PASS/PASS | **PASS** |
| 10 | 2 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 15 / PASS | PASS/PASS | **PASS** |
| 10 | 3 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 177 / PASS | PASS/PASS | **PASS** |
| 11 | 1 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 24500 / PASS | PASS/PASS | **PASS** |
| 11 | 2 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 18 / PASS | PASS/PASS | **PASS** |
| 11 | 3 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 60 / PASS | PASS/PASS | **PASS** |
| 11 | 4 | 10 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 9 / PASS | PASS/PASS | **PASS** |
| 12 | 1 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 12 / PASS | PASS/PASS | **PASS** |
| 12 | 2 | 11 | PASS/PASS | PASS | PASS | N/A | PASS | text → input | 4 / PASS | PASS/PASS | **PASS** |
| 12 | 3 | 11 | PASS/PASS | PASS | PASS | N/A | PASS | text → input | 4 / PASS | PASS/PASS | **PASS** |
| 12 | 4 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 24 / PASS | PASS/PASS | **PASS** |
| 13 | 1 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 270 / PASS | PASS/PASS | **PASS** |
| 13 | 2 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 360 / PASS | PASS/PASS | **PASS** |
| 13 | 3 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 2 / PASS | PASS/PASS | **PASS** |
| 13 | 4 | 11 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 8 / PASS | PASS/PASS | **PASS** |
| 14 | 1 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 24.7 / PASS | PASS/PASS | **PASS** |
| 14 | 2 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 0.5 / PASS | PASS/PASS | **PASS** |
| 14 | 3 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 4 / PASS | PASS/PASS | **PASS** |
| 15 | 1 | 12 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 297 / PASS | PASS/PASS | **PASS** |
| 15 | 2 | 12 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 25 / PASS | PASS/PASS | **PASS** |
| 15 | 3 | 12 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 28 / PASS | PASS/PASS | **PASS** |
| 15 | 4 | 12 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 10260 / PASS | PASS/PASS | **PASS** |
| 16 | 1 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 1.5 / PASS | PASS/PASS | **PASS** |
| 16 | 2 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 13 / PASS | PASS/PASS | **PASS** |
| 16 | 3 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 14 / PASS | PASS/PASS | **PASS** |
| 16 | 4 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 2 / PASS | PASS/PASS | **PASS** |
| 17 | 1 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 5 / PASS | PASS/PASS | **PASS** |
| 17 | 2 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 1 / PASS | PASS/PASS | **PASS** |
| 17 | 3 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 9 / PASS | PASS/PASS | **PASS** |
| 17 | 4 | 12 | PASS/PASS | PASS | PASS | N/A | N/A | text → input | 4 / PASS | PASS/PASS | **PASS** |
| 18 | 1 | 13 | PASS/PASS | PASS | PASS | PASS | PASS | matching → selectx4 | 1243 / PASS | PASS/PASS | **PASS** |
| 18 | 2 | 13 | PASS/PASS | PASS | PASS | PASS | N/A | matching → selectx4 | 2143 / PASS | PASS/PASS | **PASS** |
| 18 | 3 | 13 | PASS/PASS | PASS | PASS | PASS | PASS | matching → selectx4 | 3421 / PASS | PASS/PASS | **PASS** |
| 19 | 1 | 13 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 242|422|482|602|662|842 / PASS | PASS/PASS | **PASS** |
| 19 | 2 | 13 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 390|570|750 / PASS | PASS/PASS | **PASS** |
| 19 | 3 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 1375|9375 / PASS | PASS/PASS | **PASS** |
| 19 | 4 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 45342|45452|53152 / PASS | PASS/PASS | **PASS** |
| 20 | 1 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 4 / PASS | PASS/PASS | **PASS** |
| 20 | 2 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 30 / PASS | PASS/PASS | **PASS** |
| 20 | 3 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 50 / PASS | PASS/PASS | **PASS** |
| 20 | 4 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 250 / PASS | PASS/PASS | **PASS** |
| 21 | 1 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 21 / PASS | PASS/PASS | **PASS** |
| 21 | 2 | 14 | PASS/PASS | PASS | N/A | N/A | PASS | text → input | 12 / PASS | PASS/PASS | **PASS** |
| 21 | 3 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 37 / PASS | PASS/PASS | **PASS** |
| 21 | 4 | 14 | PASS/PASS | PASS | N/A | N/A | N/A | text → input | 19 / PASS | PASS/PASS | **PASS** |

## Доказательства

Для каждой строки используются соответствующая страница `source_render/`, скрин `shots-current/`, лист `literal-contacts/`, а также свежие JSON-gate-файлы. Полный путь указан в CSV.

Извлечённый из PDF текст используется только как дополнительный машинный контроль: при двухколоночной вёрстке/таблицах/формулах чтение PDF может менять порядок. Итоговая буквальная сверка в таких строках выполнялась визуально по рендеру ФИПИ и текущему скрину.