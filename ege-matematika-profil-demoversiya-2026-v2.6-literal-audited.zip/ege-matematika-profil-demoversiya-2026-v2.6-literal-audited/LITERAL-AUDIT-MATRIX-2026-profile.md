# ПОЗИЦИОННАЯ МАТРИЦА БУКВАЛЬНОГО АУДИТА — ЕГЭ МАТЕМАТИКА ПРОФИЛЬ 2026

Источник: официальный PDF ФИПИ `source/ege-2026-matematika-profil-demoversiya.pdf`.

`PASS` в строке означает, что конкретный официальный пример проверен по странице PDF, текущему скриншоту и свежему browser-gate. Старые отчёты не используются как доказательство.

| № | Вариант | PDF | Буквы/слова | цифры/знаки | жирный | курсив | подч. | формула | рисунок | ввод | ответ/критерии | browser | доказательство |
|---:|---:|---:|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 2 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 61 | PASS | `shots-current/t01-v01.png` + `literal-contacts-final/task-01.jpg` |
| 1 | 2 | 2 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 18 | PASS | `shots-current/t01-v02.png` + `literal-contacts-final/task-01.jpg` |
| 1 | 3 | 2 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 40 | PASS | `shots-current/t01-v03.png` + `literal-contacts-final/task-01.jpg` |
| 1 | 4 | 3 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 5 | PASS | `shots-current/t01-v04.png` + `literal-contacts-final/task-01.jpg` |
| 2 | 1 | 3 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 12 | PASS | `shots-current/t02-v01.png` + `literal-contacts-final/task-02.jpg` |
| 2 | 2 | 3 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 13 | PASS | `shots-current/t02-v02.png` + `literal-contacts-final/task-02.jpg` |
| 2 | 3 | 3 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 4 | PASS | `shots-current/t02-v03.png` + `literal-contacts-final/task-02.jpg` |
| 3 | 1 | 3 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 1,125 | PASS | `shots-current/t03-v01.png` + `literal-contacts-final/task-03.jpg` |
| 3 | 2 | 3 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 36 | PASS | `shots-current/t03-v02.png` + `literal-contacts-final/task-03.jpg` |
| 3 | 3 | 3 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 104 | PASS | `shots-current/t03-v03.png` + `literal-contacts-final/task-03.jpg` |
| 3 | 4 | 3 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 9 | PASS | `shots-current/t03-v04.png` + `literal-contacts-final/task-03.jpg` |
| 4 | 1 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,1 | PASS | `shots-current/t04-v01.png` + `literal-contacts-final/task-04.jpg` |
| 4 | 2 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,38 | PASS | `shots-current/t04-v02.png` + `literal-contacts-final/task-04.jpg` |
| 4 | 3 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,3 | PASS | `shots-current/t04-v03.png` + `literal-contacts-final/task-04.jpg` |
| 5 | 1 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,657 | PASS | `shots-current/t05-v01.png` + `literal-contacts-final/task-05.jpg` |
| 5 | 2 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,15 | PASS | `shots-current/t05-v02.png` + `literal-contacts-final/task-05.jpg` |
| 5 | 3 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,79 | PASS | `shots-current/t05-v03.png` + `literal-contacts-final/task-05.jpg` |
| 5 | 4 | 4 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 0,78 | PASS | `shots-current/t05-v04.png` + `literal-contacts-final/task-05.jpg` |
| 6 | 1 | 4 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 7 | PASS | `shots-current/t06-v01.png` + `literal-contacts-final/task-06.jpg` |
| 6 | 2 | 4 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 7 | PASS | `shots-current/t06-v02.png` + `literal-contacts-final/task-06.jpg` |
| 6 | 3 | 4 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 93 | PASS | `shots-current/t06-v03.png` + `literal-contacts-final/task-06.jpg` |
| 6 | 4 | 4 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 3 | PASS | `shots-current/t06-v04.png` + `literal-contacts-final/task-06.jpg` |
| 7 | 1 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 0,75 | PASS | `shots-current/t07-v01.png` + `literal-contacts-final/task-07.jpg` |
| 7 | 2 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 5 | PASS | `shots-current/t07-v02.png` + `literal-contacts-final/task-07.jpg` |
| 7 | 3 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 125 | PASS | `shots-current/t07-v03.png` + `literal-contacts-final/task-07.jpg` |
| 8 | 1 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 5 | PASS | `shots-current/t08-v01.png` + `literal-contacts-final/task-08.jpg` |
| 8 | 2 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 6 | PASS | `shots-current/t08-v02.png` + `literal-contacts-final/task-08.jpg` |
| 8 | 3 | 5 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 1,6 | PASS | `shots-current/t08-v03.png` + `literal-contacts-final/task-08.jpg` |
| 9 | 1 | 6 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 45 | PASS | `shots-current/t09-v01.png` + `literal-contacts-final/task-09.jpg` |
| 9 | 2 | 6 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 5 | PASS | `shots-current/t09-v02.png` + `literal-contacts-final/task-09.jpg` |
| 9 | 3 | 6 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 4900 | PASS | `shots-current/t09-v03.png` + `literal-contacts-final/task-09.jpg` |
| 10 | 1 | 6 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 19 | PASS | `shots-current/t10-v01.png` + `literal-contacts-final/task-10.jpg` |
| 10 | 2 | 6 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 15 | PASS | `shots-current/t10-v02.png` + `literal-contacts-final/task-10.jpg` |
| 10 | 3 | 6 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | numeric input | 8 | PASS | `shots-current/t10-v03.png` + `literal-contacts-final/task-10.jpg` |
| 11 | 1 | 6 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 0,1 | PASS | `shots-current/t11-v01.png` + `literal-contacts-final/task-11.jpg` |
| 11 | 2 | 7 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | PASS (source figure) | numeric input | 5 | PASS | `shots-current/t11-v02.png` + `literal-contacts-final/task-11.jpg` |
| 11 | 3 | 6 | PASS | PASS | PASS | PASS | PASS | N/A | PASS (source figure) | numeric input | 32 | PASS | `shots-current/t11-v03.png` + `literal-contacts-final/task-11.jpg` |
| 12 | 1 | 7 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 5 | PASS | `shots-current/t12-v01.png` + `literal-contacts-final/task-12.jpg` |
| 12 | 2 | 7 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | −6 | PASS | `shots-current/t12-v02.png` + `literal-contacts-final/task-12.jpg` |
| 12 | 3 | 7 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | 16 | PASS | `shots-current/t12-v03.png` + `literal-contacts-final/task-12.jpg` |
| 12 | 4 | 7 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | numeric input | −18 | PASS | `shots-current/t12-v04.png` + `literal-contacts-final/task-12.jpg` |
| 13 | 1 | 8 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t13-v01.png` + `literal-contacts-final/task-13.jpg` + `criteria-contacts/criteria-13.jpg` |
| 13 | 2 | 8 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t13-v02.png` + `literal-contacts-final/task-13.jpg` + `criteria-contacts/criteria-13.jpg` |
| 14 | 1 | 8 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 3 | PASS | `shots-current/t14-v01.png` + `literal-contacts-final/task-14.jpg` + `criteria-contacts/criteria-14.jpg` |
| 14 | 2 | 8 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 3 | PASS | `shots-current/t14-v02.png` + `literal-contacts-final/task-14.jpg` + `criteria-contacts/criteria-14.jpg` |
| 15 | 1 | 8 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t15-v01.png` + `literal-contacts-final/task-15.jpg` + `criteria-contacts/criteria-15.jpg` |
| 15 | 2 | 8 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t15-v02.png` + `literal-contacts-final/task-15.jpg` + `criteria-contacts/criteria-15.jpg` |
| 16 | 1 | 8 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t16-v01.png` + `literal-contacts-final/task-16.jpg` + `criteria-contacts/criteria-16.jpg` |
| 16 | 2 | 8 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 2 | PASS | `shots-current/t16-v02.png` + `literal-contacts-final/task-16.jpg` + `criteria-contacts/criteria-16.jpg` |
| 17 | 1 | 9 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 3 | PASS | `shots-current/t17-v01.png` + `literal-contacts-final/task-17.jpg` + `criteria-contacts/criteria-17.jpg` |
| 17 | 2 | 9 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 3 | PASS | `shots-current/t17-v02.png` + `literal-contacts-final/task-17.jpg` + `criteria-contacts/criteria-17.jpg` |
| 18 | 1 | 9 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 4 | PASS | `shots-current/t18-v01.png` + `literal-contacts-final/task-18.jpg` + `criteria-contacts/criteria-18.jpg` |
| 18 | 2 | 9 | PASS | PASS | PASS | PASS | PASS | PASS (literal visual) | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 4 | PASS | `shots-current/t18-v02.png` + `literal-contacts-final/task-18.jpg` + `criteria-contacts/criteria-18.jpg` |
| 19 | 1 | 9 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 4 | PASS | `shots-current/t19-v01.png` + `literal-contacts-final/task-19.jpg` + `criteria-contacts/criteria-19.jpg` |
| 19 | 2 | 9 | PASS | PASS | PASS | PASS | PASS | N/A | N/A | textarea + самостоятельная оценка по критериям | официальные критерии; max 4 | PASS | `shots-current/t19-v02.png` + `literal-contacts-final/task-19.jpg` + `criteria-contacts/criteria-19.jpg` |
