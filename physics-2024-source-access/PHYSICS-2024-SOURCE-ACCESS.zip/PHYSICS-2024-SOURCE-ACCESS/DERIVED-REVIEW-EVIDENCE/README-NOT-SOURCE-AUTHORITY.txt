DERIVED REVIEW EVIDENCE — NOT SOURCE AUTHORITY

Every PNG below this directory was rendered from a byte-verified tracked PDF at the recorded CURRENT_MAIN_SHA. These images are convenience review evidence only. The PDFs in SOURCE-AUTHORITY/ remain the exclusive source authority.
