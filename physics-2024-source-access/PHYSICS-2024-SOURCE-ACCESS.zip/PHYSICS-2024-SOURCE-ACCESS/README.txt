PHYSICS 2024 SOURCE ACCESS

CURRENT_MAIN_SHA=e9dfffae7275be9de829d1c5a5668e7715d8261f
ALL_REQUIRED_FIPI_2024_AUTHORITY_PRESENT=true

SOURCE-AUTHORITY/ contains byte-identical copies of the three official FIPI PDFs tracked in:
ege-source-fizika/source-fizika-2024/

Everything else in this package is DERIVED REVIEW EVIDENCE — NOT SOURCE AUTHORITY.
No external source or mirror was used. No PDF was rewritten, recompressed, or substituted.

Technical summary:
TASK_COUNT=26
SHORT_TASK_RANGE=1-20
EXTENDED_TASK_RANGE=21-26
OFFICIAL_MAX_SCORE=45
EXTENDED_TASK_MAX_POINTS=21:3,22:2,23:2,24:3,25:3,26:4

The task registry is a mechanical page/slot/type/points/visual index. Visual regions are semantic locations on the official DEMO page; crop coordinates are intentionally not asserted.
