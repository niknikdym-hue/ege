# Physics 2024 technical task registry

> DERIVED REVIEW EVIDENCE — NOT SOURCE AUTHORITY. Mechanical indexing only; no answer/crop/content authority is asserted.

- `CURRENT_MAIN_SHA=e9dfffae7275be9de829d1c5a5668e7715d8261f`
- `TASK_COUNT=26`
- `SHORT_TASK_RANGE=1-20`
- `EXTENDED_TASK_RANGE=21-26`
- `OFFICIAL_MAX_SCORE=45`
- `EXTENDED_TASK_MAX_POINTS=21:3,22:2,23:2,24:3,25:3,26:4`

| Task | Source PDF | Physical page | Position/slot | Type | Max points | Has visual | Visual page/region |
|---:|---|---:|---|---|---:|---|---|
| 1 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 3 | logical page 6; right slot, item 1/3 | SHORT | 1 | true | logical page 6, right slot: prompt graph |
| 2 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 3 | logical page 6; right slot, item 2/3 | SHORT | 1 | true | logical page 6, right slot: prompt graph |
| 3 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 3 | logical page 6; right slot, item 3/3 | SHORT | 1 | false | N/A |
| 4 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 7; left slot, item 1/3 | SHORT | 1 | true | logical page 7, left slot: lever diagram |
| 5 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 7; left slot, item 2/3 | SHORT | 2 | true | logical page 7, left slot: pendulum diagram |
| 6 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 7; left slot, item 3/3 | SHORT | 2 | false | N/A |
| 7 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 8; right slot, item 1/4 | SHORT | 1 | false | N/A |
| 8 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 8; right slot, item 2/4 | SHORT | 1 | false | N/A |
| 9 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 8; right slot, item 3/4 | SHORT | 2 | true | logical page 8, right slot: p-V graph |
| 10 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 4 | logical page 8; right slot, item 4/4 | SHORT | 2 | false | N/A |
| 11 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 5 | logical page 9; left slot, item 1/3 | SHORT | 1 | true | logical page 9, left slot: prompt graph |
| 12 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 5 | logical page 9; left slot, item 2/3 | SHORT | 1 | false | N/A |
| 13 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 5 | logical page 9; left slot, item 3/3 | SHORT | 1 | true | logical page 9, left slot: lens/ray diagram |
| 14 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 5 | logical page 10; right slot, item 1/1 | SHORT | 2 | true | logical page 10, right slot: circuit diagram and graph |
| 15 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 6 | logical page 11; left slot, item 1/2 | SHORT | 2 | true | logical page 11, left slot: prompt graphs |
| 16 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 6 | logical page 11; left slot, item 2/2 | SHORT | 1 | false | N/A |
| 17 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 6 | logical page 12; right slot, item 1/2 | SHORT | 2 | false | N/A |
| 18 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 6 | logical page 12; right slot, item 2/2 | SHORT | 2 | false | N/A |
| 19 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 7 | logical page 13; left slot, item 1/1 | SHORT | 1 | true | logical page 13, left slot: instrument image |
| 20 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 7 | logical page 14; right slot, item 1/1 | SHORT | 1 | true | logical page 14, right slot: experimental data table |
| 21 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 15; left slot, item 1/4 | EXTENDED | 3 | true | logical page 15, left slot: circuit diagram |
| 22 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 15; left slot, item 2/4 | EXTENDED | 2 | false | N/A |
| 23 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 15; left slot, item 3/4 | EXTENDED | 2 | false | N/A |
| 24 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 15; left slot, item 4/4 | EXTENDED | 3 | true | logical page 15, left slot: p-V diagram |
| 25 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 16; right slot, item 1/2 | EXTENDED | 3 | true | logical page 16, right slot: magnetic/mechanical diagram |
| 26 | `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | 8 | logical page 16; right slot, item 2/2; two official examples separated by ИЛИ | EXTENDED | 4 | true | logical page 16, right slot: diagram in official example 2 |

`VISUAL_PAGE_REGION` identifies a semantic region in the official DEMO only. No crop coordinates were inferred or created.
