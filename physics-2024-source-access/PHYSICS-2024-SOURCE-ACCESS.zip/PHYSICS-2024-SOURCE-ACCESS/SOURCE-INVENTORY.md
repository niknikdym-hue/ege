# Physics 2024 source inventory

> DERIVED REVIEW EVIDENCE — NOT SOURCE AUTHORITY. Generated only from tracked files at `origin/main` `e9dfffae7275be9de829d1c5a5668e7715d8261f`.

| Exact relative path | Filename | Bytes | Git blob SHA | SHA-256 | File type | PDF physical pages | Classification |
|---|---:|---:|---|---|---|---:|---|
| `ege-source-fizika/source-fizika-2024/.gitkeep` | `.gitkeep` | 0 | `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | empty technical placeholder (not source authority) | N/A | TECHNICAL_PLACEHOLDER |
| `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf` | `ege-2024-fizika-demoversiya.pdf` | 930467 | `c4e7e78bb83e7fbaca8a47233d0cab944b2709a8` | `746903cadd391a52948aea59155f713c7677521ba22b52c369d2473fb0fc2057` | PDF document, version 1.4, A4 landscape/two-up, not encrypted | 18 | DEMO_FILE |
| `ege-source-fizika/source-fizika-2024/ege-2024-fizika-kodifikator.pdf` | `ege-2024-fizika-kodifikator.pdf` | 712009 | `b4a37d00651af07c12270a179ab368876ee6a093` | `bc4c1ee2a603572e5342227a8c90aa34a772a22cc750164c443f4921c4eeca30` | PDF document, version 1.6, A4, not encrypted | 30 | CODIFIER_FILE |
| `ege-source-fizika/source-fizika-2024/ege-2024-fizika-specifikatsiya.pdf` | `ege-2024-fizika-specifikatsiya.pdf` | 516645 | `189371a8b6834b79a69d4c2aa3182fc80dda93bf` | `f4703bbe704c0220e44faca64cb1fe834fc06c5eeab21d57f6f428e2b3bd775c` | PDF document, version 1.4, A4/two-up, not encrypted | 7 | SPECIFICATION_FILE |

## Authority mapping

- `DEMO_FILE`: `ege-source-fizika/source-fizika-2024/ege-2024-fizika-demoversiya.pdf`
- `SPECIFICATION_FILE`: `ege-source-fizika/source-fizika-2024/ege-2024-fizika-specifikatsiya.pdf`
- `CODIFIER_FILE`: `ege-source-fizika/source-fizika-2024/ege-2024-fizika-kodifikator.pdf`
- Other official FIPI files in this tracked directory: none.
- `ALL_REQUIRED_FIPI_2024_AUTHORITY_PRESENT=true`

The `.gitkeep` entry is a repository placeholder and is not an official FIPI source file. The three PDFs under `SOURCE-AUTHORITY/` are byte-identical copies of the tracked files; no PDF content was recompressed or altered.
